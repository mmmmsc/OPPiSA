﻿// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.

#include <iostream>
#include <iomanip>
#include <iterator>

#include "SyntaxAnalysis.h"
#include "LivenessAnalysis.h"

int counter = 0;
int counter1 = 0;


using namespace std;

SyntaxAnalysis::SyntaxAnalysis(LexicalAnalysis& lex)
	: la(lex), err(false), tokenIt(la.getTokenList().begin())
{
}

// Funkcija kojom zapocinje sintaksna analiza.
// U njoj se preuzima naredni token i poziva prvi neterminalni simbol.

bool SyntaxAnalysis::Do()
{
	currT = getNextToken();
	Q();
	return !err;
}

void SyntaxAnalysis::printSyntaxErr(Token token)
{
	cout << "Syntax error! Token: " << token.getValue() << " unexpected." << endl;
}

void SyntaxAnalysis::printTokenInformation(Token token)
{
	cout << setw(20) << left << token.getValue();
	cout << setw(25) << right << token.getValue() << endl;
}


// Funkcija eat - proverava da li smo naisli na ocekujuci token.
void SyntaxAnalysis::eat(TokenType t)
{
	if (err == false)
	{
		if (currT.getType() == t)
		{
			cout << currT.getValue() << endl;
			if (t != T_END_OF_FILE)
			{
				currT = getNextToken();
			}
		}
		else
		{
			printSyntaxErr(currT);
			err = true;
		}
	}
}

// Funkcija koja dobavlja naredni token
Token SyntaxAnalysis::getNextToken()
{
	if (tokenIt == la.getTokenList().end())
		throw runtime_error("End of input file reached.");
	return *tokenIt++;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void SyntaxAnalysis::Q()
{
	if (err == false)
	{
		S();
		eat(T_SEMI_COL);
		L();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void SyntaxAnalysis::S()			// .section data
{
	if (err)
	{
		return;
	}

	TokenType curr = currT.getType();

	if (curr == T_MEM)
	{
		eat(T_MEM);
		//Variable* var = new Variable(currT.getValue(), Variable::VariableType::MEM_VAR);
		Variable* var = new Variable(Variable::VariableType::MEM_VAR, currT.getValue(), -1, no_assign);
		eat(T_M_ID);
		var->m_value = currT.getValue();
		eat(T_NUM);
		variables.push_back(var);		// dodajemo varijablu u listu
	}
	else if (curr == T_REG)
	{
		eat(T_REG);
		Variable* var = new Variable(Variable::VariableType::REG_VAR, currT.getValue(), counter1, no_assign);
		eat(T_R_ID);
		var->m_position = counter1;
		variables.push_back(var);
		counter1++;
	}
	else if (curr == T_FUNC)
	{
		eat(T_FUNC);
		Label* lab = new Label(counter, "main");
		labels.push_back(lab);
		eat(T_ID);
	}
	else if (curr == T_ID)
	{
		//nema sta da pojede jer nije token "lab"
		Label* lab = new Label(counter, currT.getValue());
		eat(T_ID);
		eat(T_COL);
		E();
		labels.push_back(lab);
	}
	else
	{
		E();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void SyntaxAnalysis::L()
{
	if (err)
	{
		return;
	}

	if (currT.getType() == T_END_OF_FILE)
	{
		eat(T_END_OF_FILE);
	}
	else
	{
		Q();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void SyntaxAnalysis::E()			
{
	if (err)
	{
		return;
	}

	TokenType curr = currT.getType();

	if (curr == T_NOP)
	{
		eat(T_NOP);
		Instruction* instr = new Instruction(I_NOP, counter);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_BLTZ)
	{
		// bltz R, L
		eat(T_BLTZ);
		Instruction* instr = new Instruction(I_BLTZ, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->lab = currT.getValue();
		eat(T_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_B)
	{
		eat(T_B);
		Instruction* instr = new Instruction(I_B, counter);
		instr->lab = currT.getValue();
		eat(T_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_SW)
	{
		eat(T_SW);
		Instruction* instr = new Instruction(I_SW, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		Variable* number = new Variable();
		number->m_value = currT.getValue();
		instr->m_src.push_back(number);
		eat(T_NUM);
		eat(T_L_PARENT);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_R_PARENT);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_LI)
	{
		eat(T_LI);
		Instruction* instr = new Instruction(I_LI, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		Variable* number = new Variable();
		number->m_value = currT.getValue();
		instr->m_src.push_back(number);
		eat(T_NUM);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_LA)
	{
		eat(T_LA);
		Instruction* instr = new Instruction(I_LA, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_M_ID);
		instructions.push_back(instr);
		counter++; 
	}
	else if (curr == T_SUB)
	{
		eat(T_SUB);
		Instruction* instr = new Instruction(I_SUB, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_ADDI)
	{
		eat(T_ADDI);
		Instruction* instr = new Instruction(I_ADDI, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		Variable* number = new Variable();
		number->m_value = (currT.getValue());
		eat(T_NUM);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_ADD)
	{
		eat(T_ADD);
		Instruction* instr = new Instruction(I_ADD, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_LW)
	{
		eat(T_LW);
		Instruction* instr = new Instruction(I_LW, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		Variable* number = new Variable();
		number->m_value = (currT.getValue());
		instr->m_src.push_back(number);
		eat(T_NUM);
		eat(T_L_PARENT);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_R_PARENT);
		instructions.push_back(instr);
		counter++; 

	}
	///// TRI DODATE INSTRUKCIJE ///// IZMENI !!!!!!!!!!!!!!, dodaje se u types.h
	else if (curr == T_BGTZ)
	{
		// bgtz R, L
		eat(T_BGTZ);
		Instruction* instr = new Instruction(I_BGTZ, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->lab = currT.getValue();
		eat(T_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_AND)
	{
		eat(T_AND);
		Instruction* instr = new Instruction(I_AND, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		instructions.push_back(instr);
		counter++;
	}
	else if (curr == T_OR)
	{
		eat(T_OR);
		Instruction* instr = new Instruction(I_OR, counter);
		instr->m_dst.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		eat(T_COMMA);
		instr->m_src.push_back(getVariable(currT.getValue()));
		eat(T_R_ID);
		instructions.push_back(instr);
		counter++;
	}
	else
	{
		err = true;
		printSyntaxErr(currT);
	}
}



Variable* SyntaxAnalysis::getVariable(string name)
{
	for (auto it = variables.begin(); it != variables.end(); it++)
	{
		if ((*it)->m_name == name)
			return (*it);
	}
}


// Funkcija koja iz source i dst skupa formira use i def skupove za svaku instrukciju.

/* void SyntaxAnalysis::def_use()
{
	cout << endl << "-------------------------------------------------------------" << endl;
	cout << "\nOBRADA SUCC I PRED KRECE\n";

	Instructions::iterator it1;

	for (it1 = instructions.begin(); it1 != instructions.end(); it1++)
	{
		for (auto sr = (*it1)->m_src.begin(); sr != (*it1)->m_src.end(); sr++)
		{
			if ((*sr)->m_type == Variable::VariableType::REG_VAR)
			{
				(*it1)->m_use.push_back((*sr));
			}
		}

		for (auto ds = (*it1)->m_dst.begin(); ds != (*it1)->m_dst.end(); ds++)
		{
			if ((*ds)->m_type == Variable::VariableType::REG_VAR)
			{
				(*it1)->m_def.push_back((*ds));
			}
		}
	}
} */

/* void SyntaxAnalysis::def_use()
{
	cout << endl << "-------------------------------------------------------------" << endl;
	cout << "\nOBRADA SUCC I PRED KRECE\n";

	Instructions::iterator it1;

	for (it1 = instructions.begin(); it1 != instructions.end(); it1++)
	{
		(*it1)->m_use = (*it1)->m_src;
		(*it1)->m_def = (*it1)->m_dst;
	}
} */

void SyntaxAnalysis::def_use() {
	cout << "------------------------------------" << endl;
	cout << "Obrada succ i pred krece" << endl;
	Instructions::iterator it1;
	for (it1 = instructions.begin(); it1 != instructions.end(); it1++)
	{
		for (auto sr1 = (*it1)->m_src.begin(); sr1 != (*it1)->m_src.end(); sr1++)
		{
			if ((*sr1)->m_type == Variable::VariableType::REG_VAR)
			{
				(*it1)->addInUse(*sr1);
			}
		}
		for (auto ds = (*it1)->m_dst.begin(); ds != (*it1)->m_dst.end(); ds++)
		{
			if ((*ds)->m_type == Variable::VariableType::REG_VAR)
			{
				(*it1)->addInDef(*ds);
			}
		}

		(*it1)->m_def = (*it1)->m_dst;
	}
}


// Funkcija koja formira pred i succ skupove.

void SyntaxAnalysis::pred_succ()
{
	for (auto it = instructions.begin(); it != instructions.end(); it++)
	{
		if ((*it)->m_type == InstructionType::I_B)
		{
			for (auto it2 = labels.begin(); it2 != labels.end(); it2++)
			{
				if ((*it)->lab == (*it2)->l_name)
				{
					for (auto it3 = instructions.begin(); it3 != instructions.end(); it3++)
					{
						if ((*it2)->position == (*it3)->m_position)
						{
							(*it)->m_succ.push_back(*it3);
							(*it3)->m_pred.push_back(*it);
						}
					}
				}
			}
		}
		else
		{
			for (auto it2 = instructions.begin(); it2 != instructions.end(); it2++) // ovaj iterator ponovo prolazi kroz instrukcoje i proverava da li postoji instrukcija koja se nalazi jedno mesto iza instrukcije na koju pokazuje ovaj iterator it (mozda ne postoji---nema naslednike)
			{
				if ((*it)->m_position + 1 == (*it2)->m_position)
				{
					(*it)->m_succ.push_back((*it2));
					(*it2)->m_pred.push_back((*it));

					if ((*it)->m_type == InstructionType::I_BLTZ || (*it)->m_type == InstructionType::I_BGTZ)
					{
						for (auto it3 = labels.begin(); it3 != labels.end(); it3++)
						{
							if ((*it3)->l_name == (*it)->lab)
							{
								for (auto it4 = instructions.begin(); it4 != instructions.end(); it4++)
								{
									if ((*it3)->position == (*it4)->m_position)
									{
										(*it)->m_succ.push_back(*it4);
										(*it4)->m_pred.push_back(*it);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

 void SyntaxAnalysis::print_instructions(Instructions* instrc)
{
	string inst_type[14] = { "NO_TYPE", "ADD", "ADDI", "SUB", "LA", "LI", "LW", "SW", "BLTZ", "B", "NOP", "BGTZ", "AND", "OR"};
	for (Instructions::iterator it = instrc->begin(); it != instrc->end(); it++)
	{
		int counter = 1;
		cout << "Type " << inst_type[(*it)->m_type] << " Pos: " << (*it)->m_position << endl;

		for (Variables::iterator i = (*it)->m_dst.begin(); i != (*it)->m_dst.end(); i++)
		{
			cout << "Dest " << " Naziv: " << (*i)->m_name << " " << endl;
		}
		for (Variables::iterator i = (*it)->m_src.begin(); i != (*it)->m_src.end(); i++) {
			cout << "Src " << " Naziv: " << (*i)->m_name << " " << endl;

		}
		
		cout << "PRED: ";
		for (Instructions::iterator itt = (*it)->m_pred.begin(); itt != (*it)->m_pred.end(); itt++)
		{
			cout << (*itt)->m_position << " ";
		}
		cout << endl;
		cout << "SUCC: ";
		for (Instructions::iterator itt = (*it)->m_succ.begin(); itt != (*it)->m_succ.end(); itt++)
		{
			cout << (*itt)->m_position << " ";
		}
		cout << endl;
		cout << "USE: ";
		for (Variables::iterator i = (*it)->m_use.begin(); i != (*it)->m_use.end(); i++)
		{
			if ((*i)->m_type != Variable::VariableType::MEM_VAR)
				cout << (*i)->m_name << '\t';
		}
		cout << endl;
		cout << "DEF: ";
		for (Variables::iterator i = (*it)->m_def.begin(); i != (*it)->m_def.end(); i++)
		{
			if ((*i)->m_type != Variable::VariableType::MEM_VAR)
				cout << (*i)->m_name << '\t';
		}
		cout << endl;
		//cout << "----------------------------------------------" << endl;
		cout << "IN: ";
		for (Variables::iterator i = (*it)->m_in.begin(); i != (*it)->m_in.end(); i++)
		{
			if ((*i)->m_type != Variable::VariableType::MEM_VAR)
				cout << (*i)->m_name << '\t';
		}
		cout << endl;
		cout << "OUT: ";
		for (Variables::iterator i = (*it)->m_out.begin(); i != (*it)->m_out.end(); i++)
		{
			if ((*i)->m_type != Variable::VariableType::MEM_VAR)
				cout << (*i)->m_name << '\t';
		}

		cout << endl << "===========================================" << endl;

	}


	
}






