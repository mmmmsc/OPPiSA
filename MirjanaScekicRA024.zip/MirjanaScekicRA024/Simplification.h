// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#pragma once
#include "Types.h"
#include "InterferenceGraph.h"
#include "IR.h"
#include <stack>

//funkcija za uproscavanje broja cvorova grafa toka smetnji
std::stack<Variable*>* doSimplification(InterferenceGraph* ig, int degree, Variables rv);