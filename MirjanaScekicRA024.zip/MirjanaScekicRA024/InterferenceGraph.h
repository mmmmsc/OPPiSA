// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.

#pragma once
#include "Types.h"
#include "IR.h"

//klasa grafa smetnji koji sadrzi matricu i velicinu
class InterferenceGraph
{
private:

	char** valuesIG;		// matrica koja predstavlja graf smetnji
	int sizeIG;				// velicina grafa smetnji - broj grafova u cvoru

public:
	InterferenceGraph() : valuesIG(NULL), sizeIG(0) {}

	~InterferenceGraph()
	{
		int i;
		for (i = 0; i < sizeIG; ++i)
		{
			delete[] valuesIG[i];
		}
		delete[] valuesIG;


	} 

	//formiranje cistog grafa smetnji
	void createValuesIG()
	{
		int i;
		int j;
		valuesIG = new char* [sizeIG];


		for (i = 0; i < sizeIG; ++i)
		{
			valuesIG[i] = new char[sizeIG];
		}


		for (i = 0; i < sizeIG; ++i)
			for (j = 0; j < sizeIG; ++j)
				valuesIG[i][j] = '-';

		//for petlja za ispis cistog nepopunjenog grafa
		for (i = 0; i < sizeIG; ++i)
		{
			for (j = 0; j < sizeIG; ++j)
				std::cout << " " << valuesIG[i][j] << " ";
			std::cout << std::endl;
		}
	}

	//popunjavanje grafa smetnji
	void printValuesIG() {

		int i;
		int j;
		std::cout << "\nIspis popunjenog grafa smetnji: \n\n";

		for (i = 0; i < sizeIG; ++i)
		{
			for (j = 0; j < sizeIG; ++j)
				if (valuesIG[i][j] == __INTERFERENCE__)
					std::cout << "* ";
				else
					std::cout << "- ";

			std::cout << std::endl;
		}


	}

	char getValuesIG(int i, int j) const
	{
		return valuesIG[i][j];

	}

	void setValuesIG(int i, int j, char c)
	{
		valuesIG[i][j] = c;

	}

	int getSizeIG() const
	{
		return sizeIG;

	}

	void setSizeIG(int s)
	{
		sizeIG = s;

	}

};

//funkcija u kojoj se formira graf smetnji i ispisuje
InterferenceGraph* doInterferenceGraph(Instructions& instructions, Variables rv);