// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#pragma once
#include "Types.h"
#include "InterferenceGraph.h"

#include <stack>


bool doResourceAllocation(std::stack<Variable*>* simplificationStack, InterferenceGraph* ig);