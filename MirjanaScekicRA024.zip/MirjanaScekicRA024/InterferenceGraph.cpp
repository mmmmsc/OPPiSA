// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#include "InterferenceGraph.h"

using namespace std;

//funkcija za formiranje grafa smetnji
//
InterferenceGraph* doInterferenceGraph(Instructions& instructions, Variables rv)
{
	cout << "--------------------------------------------------------------------" << endl;
	cout << "GRAF SMETNJI" << endl;
	InterferenceGraph* retIntGraph = new InterferenceGraph();
	

	int brojac_registarskih_promenljivih = 0;
	for (auto it = rv.begin(); it != rv.end(); it++)
	{
		if ((*it)->m_type == Variable::VariableType::REG_VAR)
		{
			brojac_registarskih_promenljivih++;
		}
	}

	retIntGraph->setSizeIG(brojac_registarskih_promenljivih);


	retIntGraph->createValuesIG();		// kreiranje inicijalnog(nepopunjenog) grafa smetnji



	//for petlja koja prolazi kroz skup instrukcija i za svaku instrukciju prolazi najpre kroz def skup
	//zatim za promenljivu koja se definise prolazi kroz out skup za tu instrukciju i proverava
	//koje promenljive iz out su razlicite od def pa za njih upisuje u graf da su u smetnji
	int i;
	int j;
	for (auto it = instructions.begin(); it != instructions.end(); it++)
	{
		for (auto defIt = (*it)->m_def.begin(); defIt != (*it)->m_def.end(); defIt++)
		{
			for (auto outIt = (*it)->m_out.begin(); outIt != (*it)->m_out.end(); outIt++)
			{
				i = (*defIt)->m_position;
				j = (*outIt)->m_position;

				i = max(0, min(i, retIntGraph->getSizeIG() - 1));	// ogranicavanje i i j na ispravne vrednosti, kako se ne bi izaslo iz matrice smetnji
				j = max(0, min(j, retIntGraph->getSizeIG() - 1));

				if (i < 0 || i >= retIntGraph->getSizeIG() || j < 0 || j >= retIntGraph->getSizeIG()) {
					throw runtime_error("Index out of bounds in interference graph.");
				}

				if (i == j)
				{
					retIntGraph->setValuesIG(i, j, __EMPTY__);
					retIntGraph->setValuesIG(j, i, __EMPTY__);
				}
				else
				{
					retIntGraph->setValuesIG(i, j, __INTERFERENCE__);
					retIntGraph->setValuesIG(j, i, __INTERFERENCE__);
				}
			}
		}
	}

	retIntGraph->printValuesIG();		// ispisuje popunjeni graf smetnji

	cout << endl << "---------------------------------------------------------------------" << endl << endl;
	return retIntGraph;


} 