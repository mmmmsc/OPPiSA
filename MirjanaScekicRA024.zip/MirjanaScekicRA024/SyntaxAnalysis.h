﻿// Autor : Mirjana Scekic, RA 24/2022
// Datum : 07.06.2024.
#pragma once

#include "LexicalAnalysis.h"
#include "Token.h"
#include "IR.h"
#include <map>

class SyntaxAnalysis
{
public:
	SyntaxAnalysis(LexicalAnalysis& lex);
	bool Do();
	Instructions instructions;
	Variables variables;
	Labels labels;

//private:
	bool err;
	LexicalAnalysis& la;
	Token currT;
	TokenList::iterator tokenIt;


	void printSyntaxErr(Token token);
	void printTokenInformation(Token token);
	void eat(TokenType tt);
	Token getNextToken();

	void Q();
	void S();
	void L();
	void E();

	Variable* getVariable(string name);

	void print_instructions(Instructions* instrc);
	void def_use();
	void pred_succ();
};

