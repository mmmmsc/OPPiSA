// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#include "LivenessAnalysis.h"

bool VariableExists(Variable* variable, Variables variables)
{
	for (auto it = variables.begin(); it != variables.end(); it++)
	{
		if (!strcmp((*it)->m_name.c_str(), variable->m_name.c_str()) && (*it)->m_type == variable->m_type)
		{
			return true;
		}
	}
	return false;
}

void livenessAnalysis(Instructions instructions)
{
	//1.
	Instructions::reverse_iterator rit;
	for (rit = instructions.rbegin(); rit != instructions.rend(); rit++) {

		Variables& out = (*rit)->m_out;
		Variables& in = (*rit)->m_in;

		Variables newOut;
		Variables newIn;

		//1 .newIn=U succIn
		Instructions::iterator it;
		for (it = (*rit)->m_succ.begin(); it != (*rit)->m_succ.end(); it++) {
			newOut.insert(newOut.end(), (*it)->m_in.begin(), (*it)->m_in.end());
		}
		newOut.sort();
		newOut.unique();

		Variables::iterator it1;

		for (it1 = (*rit)->m_use.begin(); it1 != (*rit)->m_use.end(); it1++) {
			newIn.push_back(*it1);
		}

		Variables::iterator v1;
		for (v1 = newOut.begin(); v1 != newOut.end(); v1++) {
			if (!VariableExists(*v1, (*rit)->m_def)) {
				newIn.push_back(*v1);
			}

		}
		newIn.sort();
		newIn.unique();



		out = newOut;
		in = newIn;

	}
}