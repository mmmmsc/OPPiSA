// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#include "ResourceAllocation.h"

#include "InterferenceGraph.h"
#include "Constants.h"
#include "IR.h"
#include <vector>
#include <iostream>
#include <list>
using namespace std;

//dodela resursa promenljivama
bool doResourceAllocation(stack<Variable*>* simplificationStack, InterferenceGraph* ig) {

	int i;
	int j;
	int k;
	vector<Regs> registers;		// vektor dostupnih registara
	vector<Regs>::iterator dIt;		

	vector<Variable*> coloredRegisters;		// vektor promenljivih kojima su vec dodeljeni registri
	vector<Variable*>::iterator vIt;
	Variable* topStack;		// pokazuje na promenljivu na vrhu steka

	for (k = 0; k < __REG_NUMBER__; k++)
	{
		registers.push_back((Regs)k);
	}

	cout << "\nRegistri koji su nam na raspolaganju: ";

	for (k = 0; k < __REG_NUMBER__; k++)
	{
		cout << " $t" << registers[k];
	}

	cout << "." << endl << endl;

	//naredna while petlja se izvrsava dokle god se ne isprazni stek ili dok se ne potrose
	//svi resursi kada dolazi do errora odnosno do spill

	cout << "-------------------------" << endl;
	cout << "POCETAK BOJENJA CVOROVA" << endl;
	while (!simplificationStack->empty())
	{
		registers.clear();
		for (k = 0; k < __REG_NUMBER__; k++)
		{
			registers.push_back((Regs)k);
		}

		topStack = simplificationStack->top();
		cout << "\nTrenutno na vrhu steka " << topStack->m_name << endl;

		//deo koda koji proverava obojene registre i onaj koji treba da se oboji da li imaju neku smetnju
		// za svaku obojenu promenljivu (coloredRegisters) proverava se interferencija sa trenutnom promenljivom(topStack)
		for (vIt = coloredRegisters.begin(); vIt != coloredRegisters.end(); vIt++)
		{
			cout << "\nProverava ";
			cout << topStack->m_name << " i ";
			cout << (*vIt)->m_name;
			cout << endl;

			i = topStack->m_position;
			j = (*vIt)->m_position;

			if ((*ig).getValuesIG(i, j) == __INTERFERENCE__)
			{
				if ((*vIt)->m_assignment != -1)
				{
					for (dIt = registers.begin(); dIt != registers.end(); )
					{
						if ((*dIt) == (*vIt)->m_assignment)
						{
							dIt = registers.erase(dIt);		// ako postoji interferencija registar dodeljen obojenoj promenljivoj se uklanja iz  liste dostupnih registara(registers)
						}
						else
						{
							dIt++;
						}
					}
				}
			}
		}

		//ako su svi resursi iskorisceni javice se greska spill
		//a ako nisu podesice se assignment na prvi dostupni resurs (registar)
		if (!registers.empty())
		{
			topStack->m_assignment = (registers.front());
		}
		else
		{
			cout << "SPILL" << endl;
			return false;
		}

		coloredRegisters.push_back(topStack);
		simplificationStack->pop();
	}
	cout << "KRAJ BOJENJA CVOROVA" << endl;
	cout << "---------------------" << endl;
	cout << endl;
	return true;
} 