// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.


#include "Simplification.h"

using namespace std;

//funkcija koja formira stek u koji se ubacuju cvorovi pocev od najviseg ka najnizem rangu
//usput radi i proveru da li je neki od cvorova vec u steku da ga ne bi dva puta
//ubacivao na stek
//kraj je kada se svi cvorovi postave na stek
std::stack<Variable*>* doSimplification(InterferenceGraph* ig, int degree, Variables rv)
{
	int positionWithBiggestRang;		// cuva poziciju cvora sa najvecim rangom(koji je manji od degree)
	int maxNext;					// cuva najveci rang koji je manji od degree
	int size = ig->getSizeIG();		// broj cvorova u grafu smetnji
	int rangCvora = 0;				// trenutni rang cvora

	vector<int> removed;			// vektor koji cuva pozicije cvorova koji su vec uklonjeni
	stack<Variable*>* simpSt = new stack<Variable*>;		// stek koji cuva promenljive

	while (size > 0)
	{
		positionWithBiggestRang = -1;
		maxNext = -1;
		for (int i = 0; i < ig->getSizeIG(); i++)
		{
			bool check1 = false;

			for (auto g = removed.begin(); g < removed.end(); g++)
			{
				if ((*g) == i)		// za svaki cvor u grafu se proverava da li je vec uklonjen
				{
					check1 = true;
				}
			}

			if (check1)
			{
				continue;
			}

			rangCvora = 0;
			// ako nije uklonjen racuna se rang cvora (broj interferencija sa ostalim cvorovima)
			for (int j = 0; j < ig->getSizeIG(); j++)
			{
				bool check2 = false;

				for (auto g = removed.begin(); g < removed.end(); g++)
				{
					if ((*g) == j) {
						check2 = true;
					}
				}

				if (ig->getValuesIG(i, j) == __INTERFERENCE__ && !check2)
				{
					rangCvora++;
				}
			}

			if (rangCvora > maxNext && rangCvora < degree)
			{
				maxNext = rangCvora;
				positionWithBiggestRang = i;
			}
		}

		for (auto it = rv.begin(); it != rv.end(); it++)
		{
			if ((*it)->m_position == positionWithBiggestRang)
			{
				(*simpSt).push(*it);
			}
		}

		removed.push_back(positionWithBiggestRang);
		if (positionWithBiggestRang == -1)
		{
			throw runtime_error("\nSPILL!\n");
		}
		size--;
	}

	return simpSt;
} 


