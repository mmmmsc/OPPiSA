// Autor: Mirjana Scekic, RA 24/2022
// Datum: 07.06.2024.

#pragma once

#include "Types.h"
#include "Constants.h"
#include "IR.h"
#include <list>
#include <iterator>

void livenessAnalysis(Instructions instructions);
